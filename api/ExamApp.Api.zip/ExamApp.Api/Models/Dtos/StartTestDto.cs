using System;

namespace ExamApp.Api.Models.Dtos;

public class StartTestDto
{
    public int StudentId { get; set; }
    public int TestId { get; set; }
}

