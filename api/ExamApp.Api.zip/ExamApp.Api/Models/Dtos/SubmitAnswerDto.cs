public class SubmitAnswerDto
{
    public int QuestionId { get; set; }
    public int SelectedAnswer { get; set; }
    public double TimeSpent { get; set; }
}
