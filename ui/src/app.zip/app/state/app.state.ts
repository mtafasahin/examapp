import { ActionReducerMap } from '@ngrx/store';

export interface AppState {
  // Buraya state'ler eklenecek
}

export const reducers: ActionReducerMap<AppState> = {};
