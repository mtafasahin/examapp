export interface SubTopic {
    id: number;
    name: string;
    topicId: number;
  }
  