export interface Topic {
    id: number;
    name: string;
    subjectId: number;
    gradeId: number;
  }
  