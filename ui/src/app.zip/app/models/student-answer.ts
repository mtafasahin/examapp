export interface StudentAnswer {
    testInstanceId: number;
    testQuestionId: number;
    selectedAnswerId: number;
    timeTaken: number;
}