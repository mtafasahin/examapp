export interface Subject {
    id: number;
    name: string;
  }